#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define taumax 10 /*age of resident 1~10*/
#define xtmax 10 

double xi(double x, double xt){  /*reaction norm of absolute assesment model*/
  double s;
  if(xt>x){
    s=0.0;
  }
  else{
    s=1.0;
  }
  return s;
}

double p(double x, double sig, double mu, double d){ /*normal distribution mean mu standard deviaton sig*/
  double s;
  s=d*exp(-((x-mu)*(x-mu))/(2.0*sig*sig))/(sqrt(2.0*M_PI)*sig);
  return s;
}


double pr1(double x,double xt, double mu, double sig, double N,double d){   /*prの計算,ここでは1つのコホートでの関数(pr1)をあらわす*/
  double r;
  r=0.0;
  r=xi(x,xt)*N*p(x,sig,mu,d);
  return r;
}

double Nm(double xt, double mu, double sig, double sm, double d, double N) {   /*Nmの計算*/
  double r, x;
  r = 0.0;
  for (x = 0.0; x <= 1000.0; x += d) {
    r += (1.0 - xi(x,xt))*N*p(x,sig,mu,d);
  }
  r = sm*r;
  return r;
}


int main(){
  
  char filename[250];                    /*filename*/ 
  double mlist[taumax],mu;               /*平均のリスト*/
  double mlist2[taumax],mlist3[taumax];  /*mutant平均*/
  double h;                              /*閾値の差分*/
  double sig;                            /*標準偏差*/
  double mu_ave,mu_amp,k,Dx,the;         /*稚魚の平均サイズの式*/
  double Dx2,Dx3;                        /*mitant残留型密度*/
  double pr,sPR;                         /*residentのサイズ構造*/
  double prmax,prz,pry;                  /*resident構造の積分範囲*/
  double c;                              /*全体のcompetitive ability総和*/
  double pr2,pr3,c2,c3;                  /*mutantのcompetitive ability*/
  double c0,c1;                          /*competitive abilityの係数*/
  double sr,sm;                          /*生存率*/
  double N;                              /*個体数*/
  double dwdxt,G;                        /*適応度の変化*/
  double a0,a1;                          /*アロメトリ*/
  double dl;                             /*成長率*/
  int dli;                               /*成長率*/
  double y,z;                            /*小数部と整数部*/
  int i,t;
  int tau;                               /*世代数*/
  double pd;
  double xx;  
  double xt,xt2;                    /*thershold*/
  int xti;                      /*thershold*/
  double d;                     /*increment*/
  double NDmax,NDd,NDi;         /*range of parr size*/
  double dt,dts;                /*dt:density of desident dts:density of desident per cohort*/
  int dmui,xtii;                /*dmui:difference of mean*/
  double test;
  double w;             /*fitness*/
  double w2,w3;                 /*fitness of mutant*/
  double ww2,ww3;               /*fitnessのlogの和*/
  double mc;                    /*climate change*/
  //double dww;                   /*finite-difference*/
  sig=13.0;
  sr=0.02;
  sm=0.00005;
  //xt=20.0;
  mu_ave=100.0;
  mu_amp=50.0;
  d=0.05;
  k=0.5;
  xt2=103.2;
  the=0.4;
  N=100.0;
  dt=0.0;
  h=0.5;
  dl=40.0;
  test=0.0;
  c0=0.1;
  c1=5.0;
  G=0.0;
  mc=0.6;
  FILE*fp;
  FILE*fp2;
  
  sprintf(filename,"aam-cl-ch_noevo_mo100-160mi%0.1fxt%4.2fthe%0.1fG%0.1fsig%0.1fk%0.1fsr%0.5fsm%0.6fdl%0.1fN%0.1fco%0.1eci%0.1fh%0.5fmc%4.3f.dat",mu_amp,xt2,the,G,sig,k,sr,sm,dl,N,c0,c1,h,mc);
  fp=fopen(filename,"w");

  for(i=0;i<taumax;i++){      /*mlist[i]にmuの初期値66.0を入れる*/
    mlist[i]=66.0;
  }

  prmax=mu_ave+mu_amp+dl*taumax+5.0*sig;
  pry=modf(prmax/d,&prz);

  double *PR = (double*)malloc(sizeof(double)*prz);    /*resident計算のための配列*/
  if (PR == NULL) exit(0);
  for(i=0;i<(int)prz;i++){
    PR[i]=0.0;
  }


  double *PR2 = (double*)malloc(sizeof(double)*prz);    /*resident計算のための配列*/
  if (PR2 == NULL) exit(0);
  for(i=0;i<(int)prz;i++){
    PR2[i]=0.0;
  }

  double *PR3 = (double*)malloc(sizeof(double)*prz);    /*resident計算のための配列*/
  if (PR3 == NULL) exit(0);
  for(i=0;i<(int)prz;i++){
    PR3[i]=0.0;
  }


  ww2=0.0;   /*fitness初期化*/
  ww3=0.0;
  dwdxt=0.0;

    xt=xt2;
    for(t=taumax;t<taumax+11000;t++){

      if(t<900){
	G=100.0;
      }else{
	G=0.0;
      }

      if(t>2000 && mu_ave<160.0){
        mu_ave+=mc;
      }

    /*wildtype*/
      
    sPR=0.0;                     
    for(i=0;i<(int)prz;i++){
      pr=0;
      for(tau=0;tau<taumax;tau++){
	mu=mlist[(t-tau)%taumax];
	pr+=pow(sr,tau)*pr1(d*i-tau*dl,xt,mu,sig,N,d);
      }
      PR[i]=pr;
      sPR+=PR[i];
    }    
    
    

    c=0.0;
    for(i=0;i<(int)prz;i++){          /*合計競争能力:cの計算*/
      sPR-=PR[i];
      c+=PR[i]*c0*exp(-c1*sPR);
    }
    
    /*mutant xt+h*/
    
    sPR=0.0;                    
    for(i=0;i<(int)prz;i++){
      pr2=0.0;
      pr=0.0;
      for(tau=0;tau<taumax;tau++){
        mu=mlist[(t-tau)%taumax];
        pr2+=pow(sr,tau)*pr1(d*i-tau*dl,xt+h,mu,sig,N,d);
        pr+=pow(sr,tau)*pr1(d*i-tau*dl,xt,mu,sig,N,d);
      }
      PR2[i]=pr2;
      PR[i]=pr;
      sPR+=PR[i];
    }
 
    
    c2=0.0;
    for(i=0;i<(int)prz;i++){          /*合計競争能力:cの計算*/
      sPR-=PR[i];
      c2+=PR2[i]*c0*exp(-c1*sPR);
    }
    
    
    /*mutant xt-h*/
    
    sPR=0.0;                   
    for(i=0;i<(int)prz;i++){
      pr3=0.0;
      pr=0.0;
      for(tau=0;tau<taumax;tau++){
        mu=mlist[(t-tau)%taumax];
        pr3+=pow(sr,tau)*pr1(d*i-tau*dl,xt-h,mu,sig,N,d);
        pr+=pow(sr,tau)*pr1(d*i-tau*dl,xt,mu,sig,N,d);
      }
      PR3[i]=pr3;
      PR[i]=pr;
      sPR+=PR[i];
    }
    
    c3=0.0;
    for(i=0;i<(int)prz;i++){          /*合計競争能力:cの計算*/
      sPR-=PR[i];
      c3+=PR3[i]*c0*exp(-c1*sPR);
    }

    

    
    Dx=0.0;
    for(i=0;i<(int)prz;i++){       /*翌年の残留型バイオマス*/
      Dx+=sr*PR[i];
    }
    
    mlist[(t+1)%taumax]=mu_ave+mu_amp*erf(k*(the-Dx));  /*interference competition feedback*/
    w=(1/(Nm(xt,mlist[(t-2)%taumax],sig,sm,d,N)+c))*(Nm(xt,mlist[(t-2)%taumax],sig,sm,d,N)+c);
	  w2=(1/(Nm(xt,mlist[(t-2)%taumax],sig,sm,d,N)+c))*(Nm(xt+h,mlist[(t-2)%taumax],sig,sm,d,N)+c2);
	  w3=(1/(Nm(xt,mlist[(t-2)%taumax],sig,sm,d,N)+c))*(Nm(xt-h,mlist[(t-2)%taumax],sig,sm,d,N)+c3);
	  //	  printf("time:%d mu:%lf xt:%lf w:%lf Biomass:%lf w2:%f w3:%f c:%f c2:%f c3:%f\n",t+1,mlist[(t+1)%taumax],xt,w,Dx,w2,w3,c,c2,c3);
	  
	 
	  dwdxt=(w2-w3)/(2.0*h);
	    xt=xt+G*dwdxt;

	    if(t%500==0){
	      printf("sm:%f t:%d xt:%f dwdxt:%f mu_0:%f\n",sm,t,xt,dwdxt,mu_ave);
	    }
	  
	      fprintf(fp,"%f %d %f %f %f %f  %f %f %f\n",sm,t,xt,mlist[(t+1)%taumax],Dx,dwdxt,w2,w3,mu_ave);
	  
    }
  
  

  free(PR);
  free(PR2);
  free(PR3);
  fclose(fp);
  fclose(fp2);
  return 0;
}

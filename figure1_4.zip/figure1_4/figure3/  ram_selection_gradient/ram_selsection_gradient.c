#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define taumax 10 /*age of resident 1~10*/
#define xtmax 10 


double phi(double mu, double sig, double x, double zt,double n){ /*相対評価のreaction norm*/
  double r;
  r=(1.0+erf((n*(x-mu)-(n+2.0)*zt)/(2.0*sig*sqrt(n+2.0))))/2.0;
  return r;
}


double p(double x, double sig, double mu, double d){ /*normal distribution mean mu standard deviaton sig*/
  double s;
  s=d*exp(-((x-mu)*(x-mu))/(2.0*sig*sig))/(sqrt(2.0*M_PI)*sig);
  return s;
}


double pr1(double x,double zt, double mu, double sig, double N,double d, double n){   /*prの計算,ここでは1つのコホートでの関数(pr1)をあらわす*/
  double r;
  r=0.0;
  r=phi(mu,sig,x,zt,n)*N*p(x,sig,mu,d);
  return r;
}

double Nm(double zt, double mu, double sig, double sm, double d, double N,double n) {   /*Nmの計算*/
  double r, x;
  r = 0.0;
  for (x = 0.0; x <= 1000.0; x += d) {
    r += (1.0 -phi(mu,sig,x,zt,n))*N*p(x,sig,mu,d);
  }
  r = sm*r;
  return r;
}


int main(){
  char filename[250];                    /*file name*/
  char  filename2[250];                  /*file name2*/
  double mlist[taumax],mu;               /*平均のリスト*/
  double mlist2[taumax],mlist3[taumax];  /*mutant平均*/
  double h;                              /*閾値の差分*/
  double sig;                            /*標準偏差*/
  double mu_ave,mu_amp,k,Dx,the;         /*稚魚の平均サイズの式*/
  double Dx2,Dx3;                        /*mitant残留型密度*/
  double pr,sPR;                         /*residentのサイズ構造*/
  double prmax,prz,pry;                  /*resident構造の積分範囲*/
  double c;                              /*全体のcompetitive ability総和*/
  double pr2,pr3,c2,c3;                  /*mutantのcompetitive ability*/
  double c0,c1;                          /*competitive abilityの係数*/
  double sr,sm;                          /*生存率*/
  double N;                              /*個体数*/
  double dwdzt,G;                        /*適応度の変化*/
  double a0,a1;                          /*アロメトリ*/
  double dl;                             /*成長率*/
  int dli;                               /*成長率*/
  double y,z;                            /*小数部と整数部*/
  int i,t;
  int tau;                               /*世代数*/
  double pd;
  double xx;  
  double n;                    /*thershold*/
  double zt;                      /*threshold*/
  int xti;                      /*thershold*/
  double d;                     /*increment*/
  double NDmax,NDd,NDi;         /*range of parr size*/
  double dt,dts;                /*dt:density of desident dts:density of desident per cohort*/
  int dmui,xtii;                /*dmui:difference of mean*/
  double test;
  double w;             /*fitness*/
  double w2,w3;                 /*fitness of mutant*/
  double ww2,ww3;               /*fitnessのlogの和*/
  double mc;                     /*climate-change*/
  //double dww;                   /*finite-difference*/
  sig=13.0;
  sr=0.08;
  sm=0.00025;
  //xt=20.0;
  mu_ave=160.0;
  mu_amp=50.0;
  d=0.05;
  k=0.0;
  //zt2=4.62;
  the=0.4;
  N=100.0;
  dt=0.0;
  h=0.05;
  dl=40.0;
  test=0.0;
  c0=0.1;
  c1=5.0;
  G=100.0;
  n=100.0;
  mc=0.5;
  FILE*fp;
  FILE*fp2;
  sprintf(filename,"ram_sg_zt_mo%0.1fmi%0.1fzt%0.3fthe%0.1fG%0.1fsig%0.1fk%0.1fsr%0.5fsm%0.6fdl%0.1fN%0.1fn%0.1fco%0.1eci%0.1fh%0.5f_2.dat",mu_ave,mu_amp,zt,the,G,sig,k,sr,sm,dl,N,n,c0,c1,h);
  //fp=fopen("sake_finite-difference_k=0.0_zt=0.0_sig=13.0_sr=0.08_sm=0.00005_0.00025_mu_ave=100.0_mu_amp=50.0_d=0.05_the=0.4_N=100.0_h=0.05_dl=40.0_c0=0.1_c1=5.0_4.dat","w");
  fp=fopen(filename,"w");
  sprintf(filename2,"ram_sg_mu_mo%0.1fmi%0.1fzt%0.3fthe%0.1fG%0.1fsig%0.1fk%0.1fsr%0.5fsm%0.6fdl%0.1fN%0.1fn%0.1fco%0.1eci%0.1fh%0.5f_2.dat",mu_ave,mu_amp,zt,the,G,sig,k,sr,sm,dl,N,n,c0,c1,h);
  fp2=fopen(filename2,"w");

  if(fp==NULL){
    printf("miss!");
    exit(0);
  }

  for(i=0;i<taumax;i++){      /*mlist[i]にmuの初期値66.0を入れる*/
    mlist[i]=66.0;
  }

  prmax=mu_ave+mu_amp+dl*taumax+5.0*sig;
  pry=modf(prmax/d,&prz);

  double *PR = (double*)malloc(sizeof(double)*prz);    /*resident計算のための配列*/
  if (PR == NULL) exit(0);
  for(i=0;i<(int)prz;i++){
    PR[i]=0.0;
  }


  double *PR2 = (double*)malloc(sizeof(double)*prz);    /*resident計算のための配列*/
  if (PR2 == NULL) exit(0);
  for(i=0;i<(int)prz;i++){
    PR2[i]=0.0;
  }

  double *PR3 = (double*)malloc(sizeof(double)*prz);    /*resident計算のための配列*/
  if (PR3 == NULL) exit(0);
  for(i=0;i<(int)prz;i++){
    PR3[i]=0.0;
  }

  for(zt=1.0;zt<=200.0;zt+=1.0){

  ww2=0.0;   /*fitness初期化*/
  ww3=0.0;
  dwdzt=0.0;

  for(t=taumax;t<taumax+200;t++){
    if(mu_ave<160.0 && t>100+taumax){
      mu_ave+=mc;
    }
    /*wildtype*/
      
    sPR=0.0;                     
    for(i=0;i<(int)prz;i++){
      pr=0;
      for(tau=0;tau<taumax;tau++){
	mu=mlist[(t-tau)%taumax];
	pr+=pow(sr,tau)*pr1(d*i-tau*dl,zt,mu,sig,N,d,n);
      }
      PR[i]=pr;
      sPR+=PR[i];
    }    
    
    

    c=0.0;
    for(i=0;i<(int)prz;i++){          /*合計競争能力:cの計算*/
      sPR-=PR[i];
      c+=PR[i]*c0*exp(-c1*sPR);
    }
    
    /*mutant xt+h*/
    
    sPR=0.0;                    
    for(i=0;i<(int)prz;i++){
      pr2=0.0;
      pr=0.0;
      for(tau=0;tau<taumax;tau++){
        mu=mlist[(t-tau)%taumax];
        pr2+=pow(sr,tau)*pr1(d*i-tau*dl,zt+h,mu,sig,N,d,n);
        pr+=pow(sr,tau)*pr1(d*i-tau*dl,zt,mu,sig,N,d,n);
      }
      PR2[i]=pr2;
      PR[i]=pr;
      sPR+=PR[i];
    }
 
    
    c2=0.0;
    for(i=0;i<(int)prz;i++){          /*合計競争能力:cの計算*/
      sPR-=PR[i];
      c2+=PR2[i]*c0*exp(-c1*sPR);
    }
    
    
    /*mutant xt-h*/
    
    sPR=0.0;                   
    for(i=0;i<(int)prz;i++){
      pr3=0.0;
      pr=0.0;
      for(tau=0;tau<taumax;tau++){
        mu=mlist[(t-tau)%taumax];
        pr3+=pow(sr,tau)*pr1(d*i-tau*dl,zt-h,mu,sig,N,d,n);
        pr+=pow(sr,tau)*pr1(d*i-tau*dl,zt,mu,sig,N,d,n);
      }
      PR3[i]=pr3;
      PR[i]=pr;
      sPR+=PR[i];
    }
    
    c3=0.0;
    for(i=0;i<(int)prz;i++){          /*合計競争能力:cの計算*/
      sPR-=PR[i];
      c3+=PR3[i]*c0*exp(-c1*sPR);
    }

    

    
    Dx=0.0;
    for(i=0;i<(int)prz;i++){       /*翌年の残留型バイオマス*/
      Dx+=sr*PR[i];
    }
    
    mlist[(t+1)%taumax]=mu_ave+mu_amp*erf(k*(the-Dx));  /*interference competition feedback*/
    w=(1/(Nm(zt,mlist[(t-2)%taumax],sig,sm,d,N,n)+c))*(Nm(zt,mlist[(t-2)%taumax],sig,sm,d,N,n)+c);
    w2=(1/(Nm(zt,mlist[(t-2)%taumax],sig,sm,d,N,n)+c))*(Nm(zt+h,mlist[(t-2)%taumax],sig,sm,d,N,n)+c2);
    w3=(1/(Nm(zt,mlist[(t-2)%taumax],sig,sm,d,N,n)+c))*(Nm(zt-h,mlist[(t-2)%taumax],sig,sm,d,N,n)+c3);
    //  printf("time:%d mu:%lf xt:%lf w:%lf Biomass:%lf w2:%f w3:%f c:%f c2:%f c3:%f\n",t+1,mlist[(t+1)%taumax],xt,w,Dx,w2,w3,c,c2,c3);
      
     
    //printf("t:%d mu_0:%f\n",t,mu_ave);
    if(t>taumax+100){
      ww2+=log(w2);
      ww3+=log(w3);
    }


    if(t>taumax+100){
    fprintf(fp2,"%f %d %f %f %f %f  %f %f %f\n",sm,t,zt,mlist[(t+1)%taumax],Dx,dwdzt,w2,w3,mu_ave);
    }
  }
  dwdzt=(exp(ww2/100)-exp(ww3/100))/2.0*h;
  printf("zt: %f dww: %40.39f\n",zt,dwdzt);
  fprintf(fp,"%f %40.39f\n",zt,dwdzt);
  }
  
  

  free(PR);
  free(PR2);
  free(PR3);
  fclose(fp);
  fclose(fp2);
  return 0;
}
